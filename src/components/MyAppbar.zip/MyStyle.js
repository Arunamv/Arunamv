import { makeStyles } from '@material-ui/core/styles'
const drawerWidth=240

const useStyles=makeStyles((theme)=>{
    return{

    drawer:{ 
        width:drawerWidth,
        

    },
    drawerPaper:{
        width:drawerWidth
 
    },
    active:{
        background:'#f4f4f4'
    },
    title:{
        padding:theme.spacing(3)
    },
    appbar:{ 
        width: `calc(100% - ${drawerWidth}px)`
        
    },
    toolbar:theme.mixins.toolbar

        

    
}
}
)
export default useStyles;