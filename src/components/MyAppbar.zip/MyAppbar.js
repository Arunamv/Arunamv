import { Toolbar, Typography, AppBar, makeStyles } from "@material-ui/core";
import useStyles from './MyStyle'

function MyAppbar(){
    const classes=useStyles();
    return(
         <AppBar className={classes.appbar}>
             <Toolbar>
                 <Typography>
                     This is a Appbar
                 </Typography>
             </Toolbar>
         </AppBar>
    )
}
export default MyAppbar